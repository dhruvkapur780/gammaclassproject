# Sivaan Sharma — Personal Website

This is a simple, static personal website for **Sivaan Sharma**, a Finance & Business Analytics student at **Indiana University — Kelley School of Business**.

The content and structure are based on Sivaan's LinkedIn profile, including sections for About, Experience, Education, Skills, Certifications, and Contact.

## Structure

- `index.html` — main single-page site
- `styles.css` — layout, typography, and visual design
- `script.js` — small enhancements (mobile nav toggle, dynamic year)
- `package.json` — minimal metadata; you can ignore this if you just open `index.html` in a browser

## How to view locally

### Option 1 — Open the file directly

1. Open the `sivaan-website` folder.
2. Double-click `index.html` to open it in your browser.

### Option 2 — Run a simple local server (Node.js)

1. From the `sivaan-website` folder, run:

   ```bash
   npm install
   npm start
   ```

2. Follow the URL printed in the terminal (usually `http://localhost:3000` or `http://localhost:5000`, depending on your setup).

## Customization tips

- Update copy in `index.html` (e.g., project descriptions, summary, or experience details).
- Swap the placeholder “Projects” section text for specific class, club, or internship projects.
- Adjust colors, spacing, or fonts in `styles.css` to better match a preferred personal brand.

