Travis Garcia — Professional Website
=====================================

This folder contains everything needed to view or host the website.

CONTENTS
--------
  index.html              Main page
  styles.css              Styling (navy blue theme)
  script.js               Navigation and footer behavior
  assets/
    travis-garcia-headshot.png   Profile photo

HOW TO USE
----------
• To view locally: Open index.html in a web browser (double-click or File > Open).
• To host online: Upload this entire folder to your web host. Keep the same folder structure (especially the assets/ folder).

No build step or server required. Fonts load from Google Fonts when online.
