# Saanvi Tatikonda — Personal Website

A single-page professional portfolio site. Replace all `[bracketed]` placeholders with your own content.

## Quick start

Open `index.html` in a browser, or run a local server:

```bash
cd personal-website
python3 -m http.server 8000
```

Then visit **http://localhost:8000**.

## What to replace

- **Hero:** Tagline, CTA links, and profile photo (use the `.avatar-placeholder` div or replace with an `<img>`).
- **About:** Intro paragraphs and quick facts (location, status, interests).
- **Experience:** Dates, job titles, companies, and descriptions.
- **Projects:** Titles, descriptions, images, and Live/Code links.
- **Skills:** Category names and skill lists.
- **Education:** Degrees, schools, and dates.
- **Contact:** Intro line, email, LinkedIn, GitHub, and resume PDF link.

## File structure

- `index.html` — All page content
- `styles.css` — Layout and styling
- `script.js` — Footer year and mobile menu

No build step required; edit and refresh.
