# Utsavi Gilder – Personal Website

A one-page professional site for Utsavi Gilder, built from LinkedIn profile information.

## Contents

- **About** – Background, major, and interest in business analytics
- **Education** – Indiana University Bloomington (B.S. Informatics, minor in Business, 2024–2028)
- **Skills** – CSS, Looker Studio, Coral
- **Certifications** – CBRE Project Management Job Simulation
- **Contact** – Email and LinkedIn

## How to view

1. Open `index.html` in a browser (double-click or "Open with" your browser), or  
2. From the project folder, run a simple server, e.g.  
   `python3 -m http.server 8000`  
   then visit: `http://localhost:8000`

No build step or dependencies required.
