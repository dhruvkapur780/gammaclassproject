# Mohitha Sathish Kumar — Personal Website

A professional single-page personal website built with HTML, CSS, and JavaScript. Ready to customize with your own content and deploy to GitHub Pages, Netlify, or any static host.

## How to view the site

1. Open `index.html` in your browser (double-click the file or use **File → Open**).
2. Or run a local server from this folder, for example:
   - **Python 3:** `python -m http.server 8000` then visit http://localhost:8000
   - **Node (npx):** `npx serve .` then open the URL shown

## Project structure

```
mohitha-personal-website/
├── index.html          # Single page with all sections
├── styles/
│   └── main.css        # All styles (variables, layout, responsive)
├── scripts/
│   └── main.js         # Mobile nav toggle and smooth scroll
├── assets/             # Optional images and placeholders
│   └── placeholder.svg
└── README.md           # This file
```

## Replacing placeholder content

- **Hero:** Edit the tagline and add your headshot by replacing the `src` of the hero image (or use `assets/` and point to your photo).
- **About:** Replace the bio paragraphs and about image in the About section.
- **Experience:** Update job titles, company names, dates, and bullet points in the Experience section. Replace the skill tags with your real skills.
- **Projects:** For each project card, change the title, description, image `src`, and the "View project" link `href`.
- **Contact:** Replace the email address and add your real LinkedIn and GitHub URLs.

Images in the HTML currently use [placehold.co](https://placehold.co) URLs. You can swap these for files in `assets/` (e.g. `assets/headshot.jpg`) or any other image path.

## Deploying

- **GitHub Pages:** Push this folder to a repo, then enable GitHub Pages for that repo (Settings → Pages → source: main branch).
- **Netlify:** Drag and drop this folder into [Netlify Drop](https://app.netlify.com/drop) or connect the repo.
- **Other hosts:** Upload the contents of this folder to any static hosting service.

## License

Content and design are for personal use. Replace all placeholder text and images with your own before publishing.
