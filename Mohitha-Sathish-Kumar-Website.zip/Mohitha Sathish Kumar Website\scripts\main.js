(function () {
  "use strict";

  // Mobile nav toggle
  var navToggle = document.querySelector(".header__nav-toggle");
  var nav = document.querySelector(".header__nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", function () {
      var expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", !expanded);
      nav.classList.toggle("is-open", !expanded);
    });

    // Close nav when a link is clicked (for anchor links)
    var navLinks = nav.querySelectorAll(".header__nav-link");
    navLinks.forEach(function (link) {
      link.addEventListener("click", function () {
        navToggle.setAttribute("aria-expanded", "false");
        nav.classList.remove("is-open");
      });
    });
  }

  // Smooth scroll for anchor links (enhancement when JS is available)
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener("click", function (e) {
      var href = this.getAttribute("href");
      if (href === "#") return;
      var target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });
})();
