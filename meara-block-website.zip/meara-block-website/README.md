# Jason Ballinger – Personal Website

A single-page personal website for **Jason Ballinger**, based on his LinkedIn profile. The site highlights experience in software engineering, robotics, leadership, and teaching.

## Structure

- `index.html` – Main page with sections for About, Experience, Highlights, Skills, Education, and Contact.
- `styles.css` – Modern, responsive styling with a dark theme and accent color.
- `script.js` – Small enhancements (mobile navigation toggle, dynamic year).

## Running the site

No build step is required.

1. Open the project folder in your editor.
2. Double-click `index.html` or open it with your browser of choice.

Optionally, you can serve it with a lightweight dev server (for example, using the VS Code / Cursor Live Server extension or `npx serve`).

