# Akshay Boddapu — Professional Website

This is a simple, modern, single-page portfolio site.

## Run locally

Option A (quickest): open `index.html` in your browser.

Option B (recommended): run a local server:

```bash
cd "/Users/sunehri/akshay-boddapu-site/Akshay-Boddapu"
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Update content

Edit:
- `index.html` for text/sections and links
- `styles.css` for styling
- `assets/profile.png` for the profile photo

