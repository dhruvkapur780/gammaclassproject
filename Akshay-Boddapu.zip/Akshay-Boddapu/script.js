const navToggle = document.querySelector(".nav__toggle");
const navLinks = document.querySelector("#navLinks");

function setNavOpen(isOpen) {
  navToggle?.setAttribute("aria-expanded", String(isOpen));
  navLinks?.setAttribute("data-open", String(isOpen));
}

navToggle?.addEventListener("click", () => {
  const isOpen = navToggle.getAttribute("aria-expanded") === "true";
  setNavOpen(!isOpen);
});

navLinks?.addEventListener("click", (e) => {
  const target = e.target;
  if (target instanceof HTMLAnchorElement) setNavOpen(false);
});

document.addEventListener("click", (e) => {
  if (!navToggle || !navLinks) return;
  const target = e.target;
  if (!(target instanceof Node)) return;
  if (!navLinks.contains(target) && !navToggle.contains(target)) setNavOpen(false);
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") setNavOpen(false);
});

const yearEl = document.querySelector("#year");
if (yearEl) yearEl.textContent = String(new Date().getFullYear());

const form = document.querySelector("#contactForm");
const formNote = document.querySelector("#formNote");

form?.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!formNote) return;
  formNote.textContent =
    "Thanks! This demo form doesn’t send yet — please use the Email button, or wire this to Formspree/Netlify Forms.";
});

