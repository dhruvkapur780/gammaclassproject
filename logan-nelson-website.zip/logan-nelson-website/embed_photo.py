
import base64
import sys

# Usage: python3 embed_photo.py path/to/your/photo.jpg
photo_path = sys.argv[1] if len(sys.argv) > 1 else "logansenior2024_cropped.jpg"

with open(photo_path, "rb") as f:
    data = base64.b64encode(f.read()).decode()

html_path = "logan-nelson.html"
with open(html_path, "r") as f:
    html = f.read()

# Replace the portrait placeholder with the actual image
old = """      <div class="portrait-placeholder">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
        <span>Add Your Photo</span>
      </div>"""

new = f'''      <img src="data:image/jpeg;base64,{data}" style="width:100%;height:100%;object-fit:cover;object-position:center top;" alt="Logan Nelson" />'''

html = html.replace(old, new)
with open(html_path, "w") as f:
    f.write(html)
print("Done! Photo embedded.")
