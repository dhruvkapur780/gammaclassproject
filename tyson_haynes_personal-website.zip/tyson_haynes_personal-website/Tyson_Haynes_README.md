# Tyson Haynes — Personal Website

A personal website for college student Tyson Haynes.

## Structure

- **Hero** — Name, year/major/school, brief intro, and call-to-action buttons
- **About** — Bio, contact details, skills & interests
- **Experience & Education** — Timeline of school, internships, and activities
- **Projects** — Grid of class projects, side projects, or hackathons
- **Contact** — Closing message and links

## Getting Started

1. Open `index.html` in a browser, or run a local server:

   ```bash
   cd personal-website
   python3 -m http.server 8000
   ```

2. Visit `http://localhost:8000`

## Customization

Replace all `[placeholder]` text with your real content:

- Professional title and bio
- Location, email, LinkedIn, GitHub
- Job history and education
- Project names, descriptions, and links
- Skills list
- Profile photo (replace the hero image placeholder with an `<img>` tag)

## Tech

- HTML5
- CSS3 (custom properties, flexbox, grid)
- Vanilla JavaScript (mobile nav, smooth scroll, dynamic year)
