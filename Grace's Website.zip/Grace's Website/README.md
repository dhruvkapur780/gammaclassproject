# Grace Friedman — Personal Website

A one-page professional site. Replace all `[bracketed]` placeholders in `index.html` with your real content.

## Quick start

Open `index.html` in a browser, or run a local server:

```bash
# From this folder
python3 -m http.server 8000
```

Then visit http://localhost:8000

## What to customize

- **Hero**: Tagline, CTA, and hero image (replace the placeholder div with an `<img>` or link to your photo).
- **About**: Bio paragraphs and “Quick facts” (location, role, focus).
- **Experience**: Timeline items — add/remove entries and fill in dates, titles, companies, descriptions.
- **Projects**: Project cards — add images, titles, descriptions, and real links for “View project”.
- **Contact**: Intro line and links (email, LinkedIn, Twitter, resume URL).
- **Footer**: Optional tagline.

Images: use the existing `.placeholder-image` divs or replace with `<img src="your-image.jpg" alt="Description">`.

## Files

- `index.html` — structure and content
- `styles.css` — layout and styling (colors and fonts are in `:root` at the top)
- `script.js` — footer year, mobile menu

No build step required. Edit and refresh.
