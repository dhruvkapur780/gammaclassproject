# Ethan Abilius — Website

Sleek, modern single-page site with a cream color scheme and crimson accents.

## Run locally

- Open `index.html` in a browser, or
- From this folder, run a simple server (optional):
  - `python3 -m http.server 5173`
  - then visit `http://localhost:5173`

## Update content

Edit `index.html` to change sections (About, Experience, Education, Skills, Contact).

