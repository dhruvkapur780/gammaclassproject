const byId = (id) => document.getElementById(id);

function setYear() {
  const el = byId("year");
  if (el) el.textContent = String(new Date().getFullYear());
}

function setupHeaderElevation() {
  const header = document.querySelector(".site-header");
  if (!header) return;

  const onScroll = () => {
    header.dataset.elevated = window.scrollY > 6 ? "true" : "false";
  };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
}

function setupMobileNav() {
  const toggle = document.querySelector(".nav-toggle");
  const links = byId("nav-links");
  if (!toggle || !links) return;

  const close = () => {
    links.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  };

  toggle.addEventListener("click", () => {
    const isOpen = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  links.querySelectorAll("a").forEach((a) => {
    a.addEventListener("click", () => close());
  });

  document.addEventListener("click", (e) => {
    if (!links.classList.contains("open")) return;
    if (e.target === toggle || toggle.contains(e.target)) return;
    if (e.target === links || links.contains(e.target)) return;
    close();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") close();
  });
}

function setupActiveNav() {
  const sections = [
    "about",
    "experience",
    "education",
    "skills",
    "contact",
  ]
    .map((id) => document.getElementById(id))
    .filter(Boolean);

  const navLinks = Array.from(document.querySelectorAll(".nav-links a"));
  if (!sections.length || !navLinks.length) return;

  const setCurrent = (id) => {
    navLinks.forEach((a) => {
      const isCurrent = a.getAttribute("href") === `#${id}`;
      if (isCurrent) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
  };

  const observer = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible?.target?.id) setCurrent(visible.target.id);
    },
    {
      root: null,
      rootMargin: "-20% 0px -65% 0px",
      threshold: [0.08, 0.15, 0.25, 0.35],
    },
  );

  sections.forEach((s) => observer.observe(s));
}

setYear();
setupHeaderElevation();
setupMobileNav();
setupActiveNav();

