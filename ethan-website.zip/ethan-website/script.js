const byId = (id) => document.getElementById(id);

function setYear() {
  const el = byId("year");
  if (el) el.textContent = String(new Date().getFullYear());
}

function setupHeaderElevation() {
  const header = document.querySelector(".site-header");
  if (!header) return;

  const onScroll = () => {
    header.dataset.elevated = window.scrollY > 6 ? "true" : "false";
  };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
}

function setupMobileNav() {
  const toggle = document.querySelector(".nav-toggle");
  const links = byId("nav-links");
  if (!toggle || !links) return;

  const close = () => {
    links.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  };

  toggle.addEventListener("click", () => {
    const isOpen = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  links.querySelectorAll("a").forEach((a) => {
    a.addEventListener("click", () => close());
  });

  document.addEventListener("click", (e) => {
    if (!links.classList.contains("open")) return;
    if (e.target === toggle || toggle.contains(e.target)) return;
    if (e.target === links || links.contains(e.target)) return;
    close();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") close();
  });
}

function setupActiveNav() {
  const sections = [
    "journey",
    "contact",
  ]
    .map((id) => document.getElementById(id))
    .filter(Boolean);

  const navLinks = Array.from(document.querySelectorAll(".nav-links a"));
  if (!sections.length || !navLinks.length) return;

  const setCurrent = (id) => {
    navLinks.forEach((a) => {
      const isCurrent = a.getAttribute("href") === `#${id}`;
      if (isCurrent) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
  };

  const observer = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible?.target?.id) setCurrent(visible.target.id);
    },
    {
      root: null,
      rootMargin: "-20% 0px -65% 0px",
      threshold: [0.08, 0.15, 0.25, 0.35],
    },
  );

  sections.forEach((s) => observer.observe(s));
}

function setupAdventure() {
  const rail = document.querySelector(".adventure-rail");
  const panels = document.querySelectorAll(".adventure-panel");
  if (!rail || !panels.length) return;

  const setActivePanel = (id) => {
    panels.forEach((panel) => {
      const isActive = panel.dataset.panel === id;
      panel.classList.toggle("is-active", isActive);
    });

    rail.querySelectorAll(".rail-node").forEach((node) => {
      const isCurrent = node.dataset.node === id;
      node.classList.toggle("is-current", isCurrent);
    });
  };

  rail.addEventListener("click", (e) => {
    const node = e.target.closest(".rail-node");
    if (!node) return;
    const id = node.dataset.node;
    if (id) setActivePanel(id);
  });

  document.querySelectorAll(".panel-choices .choice[data-go]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.go;
      if (id) setActivePanel(id);
    });
  });
}

setYear();
setupHeaderElevation();
setupMobileNav();
setupActiveNav();
setupAdventure();

